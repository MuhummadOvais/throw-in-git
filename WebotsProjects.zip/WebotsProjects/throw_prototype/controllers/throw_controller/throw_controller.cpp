#include <webots/Supervisor.hpp>
#include <webots/Camera.hpp>
#include <webots/LED.hpp>
#include <webots/Motor.hpp>
#include <RobotisOp2MotionManager.hpp>
#include <iostream>
using namespace webots;
using namespace managers;
using namespace std;
enum State { SEARCH, ALIGN, THROWIN };
class ThrowController : public Supervisor {
public:
  ThrowController() : state(SEARCH), lastState(THROWIN), stepCount(0) {
    timeStep = (int)getBasicTimeStep();
    camera = getCamera("Camera");
    camera->enable(timeStep);
    motion = new RobotisOp2MotionManager(this, "motion_4096.bin");
    LED *h = getLED("HeadLed");
    if (h) h->set(0xFF0000);
    shoulderL = getMotor("ShoulderL");
    shoulderR = getMotor("ShoulderR");
    armUpperL = getMotor("ArmUpperL");
    armUpperR = getMotor("ArmUpperR");
    armLowerL = getMotor("ArmLowerL");
    armLowerR = getMotor("ArmLowerR");
    ballNode = getFromDef("BALL");
  }
  void run() {
    motion->playPage(1);
    while (motion->isMotionPlaying()) step(timeStep);
    cout << "[INFO] Ready" << endl;
    while (step(timeStep) != -1) {
      stepCount++;
      int bx=0, area=0;
      bool found = detect(bx, area);
      int w = camera->getWidth();
      bool changed = (state != lastState);
      lastState = state;
      switch (state) {
        case SEARCH:
          if (changed) { cout << "[STATE] SEARCH" << endl; motion->playPage(20); }
          if (found) state = ALIGN;
          break;
        case ALIGN:
          if (!found) { state = SEARCH; break; }
          if (bx > w/10 && bx < w*9/10) { state = THROWIN; }
          else if (bx < w/2) { if (stepCount%30==0) motion->playPage(20); }
          else { if (stepCount%30==0) motion->playPage(21); }
          break;
        case THROWIN:
          cout << "[STATE] THROW-IN" << endl;
          motion->playPage(1);
          while (motion->isMotionPlaying()) step(timeStep);
          doThrow();
          motion->playPage(1);
          while (motion->isMotionPlaying()) step(timeStep);
          cout << "[INFO] Done" << endl;
          state = SEARCH;
          break;
      }
    }
  }
private:
  int timeStep, stepCount;
  State state, lastState;
  Camera *camera;
  RobotisOp2MotionManager *motion;
  Motor *shoulderL, *shoulderR, *armUpperL, *armUpperR, *armLowerL, *armLowerR;
  Node *ballNode;
  void doThrow() {
    Node *me = getSelf();
    const double *rp = me->getPosition();
    Field *bf = ballNode ? ballNode->getField("translation") : nullptr;
    shoulderL->setPosition(-2.6); shoulderR->setPosition(2.6);
    armUpperL->setPosition(-1.5); armUpperR->setPosition(1.5);
    armLowerL->setPosition(-0.5); armLowerR->setPosition(0.5);
    for (int i=0;i<80;i++) {
      if (bf) { double p[3]={rp[0],rp[1]+0.1,rp[2]+0.4+(i*0.004)}; bf->setSFVec3f(p); }
      step(timeStep);
    }
    shoulderL->setPosition(-0.5); shoulderR->setPosition(0.5);
    armUpperL->setPosition(1.0); armUpperR->setPosition(-1.0);
    for (int i=0;i<50;i++) {
      if (bf) { double p[3]={rp[0],rp[1]+0.3+(i*0.06),rp[2]+0.7-(i*0.02)}; bf->setSFVec3f(p); }
      step(timeStep);
    }
    for (int i=0;i<60;i++) step(timeStep);
  }
  bool detect(int &xc, int &sz) {
    const unsigned char *img = camera->getImage();
    if (!img) return false;
    int w=camera->getWidth(),h=camera->getHeight(),cnt=0; long sx=0;
    for (int x=0;x<w;x+=2) for (int y=0;y<h;y+=2) {
      int r=Camera::imageGetRed(img,w,x,y),g=Camera::imageGetGreen(img,w,x,y),b=Camera::imageGetBlue(img,w,x,y);
      if (r<80&&g<80&&b<80){cnt++;sx+=x;}
    }
    sz=cnt; if(cnt<20) return false;
    xc=sx/cnt; return true;
  }
};
int main(){ThrowController r;r.run();return 0;}
